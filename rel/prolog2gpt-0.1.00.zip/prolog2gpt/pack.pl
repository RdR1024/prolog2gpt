name(prolog2gpt).
title('Library of prolog predicates to access the GPT API').
version('0.1.00').
author('Richard de Rozario','richard.derozario@gmail.com').
home('https://github.com/RdR1024/prolog2gpt').
download('https://github.com/RdR1024/prolog2gpt/raw/main/rel/prolog2gpt-0.1.00.zip').